package com.base;

public class Hija extends Padre {
	
	public void saludar(String nombre, String ciudad) {
		System.out.println("Hola desde hija "+nombre+" en "+ciudad);
	}
}
