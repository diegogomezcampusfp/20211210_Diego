package com.base;

public abstract class Padre {

	public String saludar(String nombre) {
		return "Hola "+nombre;

	}
	
	public void saludar(String nombre, String ciudad) {
		System.out.println("Hola "+nombre+" en "+ciudad);
	}
}
