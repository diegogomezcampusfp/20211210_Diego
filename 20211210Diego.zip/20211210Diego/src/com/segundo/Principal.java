package com.segundo;

import com.base.Hija;
import com.base.Padre;
import com.primero.Alumno;

public class Principal {

	public static void main(String[] args) {
		
		Alumno alumno1= new Alumno(1,"Juan L�pez",4.85f); 
		Alumno alumno2= new Alumno(2,"Mar�a P�rez",6.85f);
		Alumno alumno3= new Alumno(3,"Luis S�nchez",8.85f);
		
		float notaAlumno2=alumno2.getCalificacion();
		System.out.println("La nota de alumno2 es: "+notaAlumno2);
		
		Hija hija=new Hija();
		hija.saludar("Mar�a", "Madrid");
	}

}
